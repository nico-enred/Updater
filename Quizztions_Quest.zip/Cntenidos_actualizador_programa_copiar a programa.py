# *********************************Programa Viejo*******************************
import urllib.request
import sys
import subprocess
# **************Comprobar versión del programa*************
url_check_version=('https://raw.githubusercontent.com/nico-enred/Updater/refs/heads/main/Version_check')
def check_version():
    inside_url_origen=[]
    fhand=urllib.request.urlopen(url_check_version)
    for line in fhand:
        line=line.decode().strip()
        inside_url_origen.append(line)
    fhand.close()
    return inside_url_origen
in_url_origen=check_version()#llamamos la función para tener su return disponible como parametro

def extract_content_from_url_origin(in_url_origen):#extraígo el contenido de la url.
    new_version=in_url_origen[0]#La nueva versión que está en la primera línea
    downloading_new_file_url=in_url_origen[1]#La url del archivo nuevo para descargar
    modifications=in_url_origen[3:]#Las modificaciones que contiene el nuevo programa. De la tercera línea en adelante
    return new_version,downloading_new_file_url,modifications

new_version,downloading_new_file_url,modifications=extract_content_from_url_origin(in_url_origen)#Se llama la función para tener disponibles
                                                                                                #las variables

def get_current_version():#Obtenemos la versión actual del archivo del archivo current_version.txt
    with open('current_version.txt','r') as fhand2:
        for line in fhand2:
            return line.strip()#it exists after reading the first line. if ever were added more lines the return should move out of the loop.
        
current_version=get_current_version()

def change_to_new_version_in_currrent_version(new_version):#Cambiar version en current_version.txt
    with open('current_version.txt','w') as fhand3:
        fhand3.write(new_version)
def download_new_file(downloading_new_file_url):#Descargar archivo nuevo desde la url que hay en la segunda posición
    data=urllib.request.urlopen(downloading_new_file_url).read()
    with open('New_Ahorcado.py','wb') as fhand4:
        fhand4.write(data)
# ***************terminate program and start new one***************************************
def terminate_program(): #to be run on the program to delete after all the checks
    sys.exit()
    
def start_updater():
    subprocess.Popen(['python3','Updater_7.py'])#after checking there is a new version in the old program, it starts the updater
def actualizar():
    change_to_new_version_in_currrent_version(new_version)
    download_new_file(downloading_new_file_url)
    start_updater()
    terminate_program()
    
def no_actualizar():
    boton_yes.grid_remove()
    boton_no.grid_remove()
    
identificador=None
def brilli_boton(boton):
    global identificador
    if boton.cget('fg_color')=='light green':
        boton.configure(fg_color='green')
    else:
        boton.configure(fg_color='light green')
    identificador=root.after(1000,brilli)
def create_widgets_update():
    if current_version!=new_version:
        frame_actualizar=ctk.CTkFrame(root,fg_color='light blue',border_color='blue',border_width=5)
        label_show_version=ctk.CTkLabel(frame_actualizar,
                                        text=f'La versión actual es:{current_version}. Hay una nueva versión disponible.\n¿Quiere actualizar?'
                                        ,fg_color='green',border_color='yellow',border_width=2)
        label_show_version.grid_configure(row=0,
                                          column=0,columnspan=3,sticky='nswe')
        label_show_modification=ctk.CTkLabel(frame_actualizar,text=f'Las modificaciones que se añadirán son:\n{modifications}')
        label_show_modification.grid_configure(row=1,
                                               column=0,columnspan=3,sticky='nswe')
        boton_yes=ctk.CTkButton(frame_actualizar,text='Actualizar',fg_color='light green',hover_color='green',command=actualizar)
        boton_yes.grid_configure(row=2
                                 ,column=0)
        boton_no=ctk.CTkButton(frame_actualizar,text='No Actualizar',fg_color='pink',hover_color='red',command=no_actualizar)
        boton_no.grid_configure(row=2,
                                column=3)
import customtkinter as ctk
root=ctk.CTk()
        
# Ya tenemos los valores de la versión actual y de la versión nueva. Los comparamos
if current_version!=new_version: #si se cumple la condición empezamos la actualización
    create_widgets_update()
    frame_actualizar.tkraise()
    brilli_boton(boton_yes) 
    
