import os
import sys
import subprocess
def check_existence_old_file():
    return os.path.exists('Ahorcado.py')

def check_existence_new_file():
    return os.path.exists('New_Ahorcado.py')

def delete_old_file():
    if check_existence_old_file() and check_existence_new_file():
        os.remove('Ahorcado.py')
        return True
    else:
        return False
    
def rename_new_file(old_file_terminated):
    if old_file_terminated:
        os.rename('New_Ahorcado.py','Ahorcado.py')
        return True
    else:
        return False
        
def start_new_program():
    subprocess.Popen(['python3','Ahorcado.py'])#the updater starts the new program after doing all checks, and deleting old program
    
if check_existence_new_file() and check_existence_old_file():
    old_file_terminated=delete_old_file()
    if rename_new_file(old_file_terminated):
        start_new_program()    

sys.exit()


                
