import urllib.request


url=('https://github.com/nico-enred/Updater/raw/refs/heads/main/1111111111.png.zip')
data=urllib.request.urlopen(url).read()
with open('a_ver.zip','wb') as fhand:
        fhand.write(data)