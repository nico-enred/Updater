import random #modulo de aletoriedad
import json # para trabajar con archivos json
import os   #para trabajar con las herramientas del sistema
from tkinter import filedialog # el metodo filedialog permite interactuar con las ventanas del sistema
from datetime import datetime
import sys


if getattr(sys,'frozen', False ): #comprueba si py installer ha creado la marca frozen al crear el ejecutable
    carpeta_base=os.path.dirname(sys.executable)#toma la direccion donde está el ejecutable en windows
    Updater_ruta_absoluta=os.path.join(carpeta_base,'Updater.exe')
else:
    carpeta_base=os.path.dirname(os.path.abspath(__file__))#toma la direccion donde está el ejecutable en linux
    Updater_ruta_absoluta=os.path.join(carpeta_base,'Updater.py')
carpeta_imagenes=os.path.join(carpeta_base,'Images') #crea la dirección uniendo la ruta base con el nombre de la carpeta
carpeta_config=os.path.join(carpeta_base,'Config')
carpeta_json=os.path.join(carpeta_base,'JSON')
carpeta_sounds=os.path.join(carpeta_base,'Sounds')
carpeta_stats=os.path.join(carpeta_base,'Stats')
current_version_absoluta=os.path.join(carpeta_base,'current_version.txt')


    
indice_inicio_P1=-1
elige_colores=['red', 'blue', 'green', 'yellow', 'purple', 'orange', 'pink', 'brown', 'cyan', 'gray','black']
nameP1=''
players_data=[]
count_right_answers=0
count_wrong_answers=0
lista_check_boxes=[]
pregunta_actual=0
pregunta_actual=0
# ***********bloque de condiciones para la legibilidad de colores y nombres*******************
def color_conditon_readibility(indice_inicio_PX,widget_nombre_playerX):
    global indice_inicio_P1
    widget_nombre_playerX.configure(fg_color=elige_colores[indice_inicio_PX])
    if indice_inicio_PX==0:
        widget_nombre_playerX.configure(text_color='black')
    if indice_inicio_PX==1:
        widget_nombre_playerX.configure(text_color='yellow')
    if indice_inicio_PX>1 and indice_inicio_PX<9:
        widget_nombre_playerX.configure(text_color='black')
    if indice_inicio_PX>9:
        widget_nombre_playerX.configure(text_color='yellow')
def color_conditon_choice(indice_inicio_PX,boton_color_choice_PX):
    global indice_inicio_P1
    global elige_colores
    if (indice_inicio_PX+1)%len(elige_colores)==0:
        indice_inicio_PX=-1
    indice_inicio_PX+=1
    boton_color_choice_PX.configure(fg_color=elige_colores[indice_inicio_PX])
    if indice_inicio_PX==0:
        boton_color_choice_PX.configure(text_color='black')
    if indice_inicio_PX==1:
        boton_color_choice_PX.configure(text_color='yellow')
    if indice_inicio_PX>1 and indice_inicio_PX<9:
        boton_color_choice_PX.configure(text_color='black')
    if indice_inicio_PX>9:
        boton_color_choice_PX.configure(text_color='yellow')
    return indice_inicio_PX
def solve_no_color_choice(indice_inicio_PX,entrada_nombre_playerX,boton_color_choice_PX,X):
    if indice_inicio_PX<0:
        boton_color_choice_PX.configure(text='No olvides escoger tu color',bg_color='white')
        return False
    else:
        boton_color_choice_PX.configure(text=f'Este será tu color\n{entrada_nombre_playerX.get()}')
        return True    
# **********funciones para elegir colores*************
def color_choice_P1():
    global indice_inicio_P1
    indice_inicio_P1=color_conditon_choice(indice_inicio_P1,boton_color_choice_P1)    
# ********************Dar color al hacer intro en el Entry de nombre a esa Entrada***************************
def color_data_P1(event):
    global lista_check_boxes
    global lista_categorias_seleccionadas
    if solve_no_color_choice(indice_inicio_P1,entrada_nombre_player1,boton_color_choice_P1,1):
        color_conditon_readibility(indice_inicio_P1,entrada_nombre_player1)
        boton_start_game.configure(state='normal',text='Haz click aquí para empezar a jugar',font=('Quicksand',30,'bold'),corner_radius=8,text_color='black',fg_color='white',hover_color=verde_andaluz)
# ***************************Before starting the game******Warning label_check********************************
# ***************************Check for color choice, no player without color and no double selection**********
def check_colors_b4_start():
    global indice_inicio_P1
    if indice_inicio_P1!=-1:
        return True
    else:
        return False
# ***************************Before starting the game******Warning label_check********************************
# ***************************Check for name choice, no player without name and no double selection**********
def check_names_b4_start():
    global indice_inicio_P1
    if entrada_nombre_player1.get()=='':
        return False
    else:
        return True
# *******************************If there are no WARNINGS we can finally add the data from players to a list using tuples.
# *******************************Add data from players to list players_data****************************************
def add_data_to_list():
    global indice_inicio_P1
    global players_data
    Jugador_1_dict={'color':indice_inicio_P1,'nombre':entrada_nombre_player1.get(),'aciertos':0,'fallos':0}
    players_data.append(Jugador_1_dict)
#****************************************this is what happens when you click the start game button*******************
limite_tiempo_partida=10
def check_before_start():
    global indice_inicio_P1
    global players_data
    global content_all_files_json
    global limite_errores_partida
    global limite_tiempo_partida
    categories_selected_to_play()
    if check_colors_b4_start() and check_names_b4_start() and check_sihay_categorias_b4_jugar():
        add_data_to_list()
        marcadores()
        categories_selected_to_play()
        frame_juego.tkraise()
        rutina_1_jugador()
        limite_errores_partida=limites_errores_juego()
        limite_tiempo_partida=limites_tiempo_juego()
    else:
        label_warning.configure(text='Debes elegir color, nombre y, al menos, una categoría.',font=('Quicksand',30,'bold'),fg_color='white',text_color='black',wraplength=750)
def categories_selected_to_play():
    global lista_check_boxes
    global content_all_files_json
    global total_de_preguntas_por_partida
    lista_categorias_seleccionadas=[]
    lista_categorias_seleccionadas_ending_json=[]
    content_all_files_json=[]
    for x in lista_check_boxes:
        if x.cget('fg_color')=='yellow':
            lista_categorias_seleccionadas.append(x.cget('text'))
    for x in lista_categorias_seleccionadas:
        lista_categorias_seleccionadas_ending_json.append(x+'.json')
    for i in range (len(lista_categorias_seleccionadas_ending_json)): 
        with open(os.path.join(carpeta_json,lista_categorias_seleccionadas_ending_json[i]),'r',encoding='utf-8') as fhand:
            content_all_files_json.append(json.load(fhand))#aquí están todos las listas de diccionarios que hay en todos los .json encontrados
    total_de_preguntas_por_partida=preguntas_totales_partida()
def check_sihay_categorias_b4_jugar():
    global lista_check_boxes
    yellow_list=[]
    for x in lista_check_boxes:
        if x.cget('fg_color')=='yellow':
            yellow_list.append(x)
            if len(yellow_list)>0:
                return True
    return False
#*****************************************************************************Código FRAME_JUEGO******************************************************************************************
# *****************************************************************************************************************************************************************************************
def marcadores():
    global indice_inicio_P1
    global players_data
    global elige_colores
    global count_right_answers
#**************************************************intentar reducir esto usando range cuando aprendamos clases***************************************************************************
    P1=players_data[0]
    label_marcador_P1.configure(text=f"Jugador\n{P1['nombre']}",fg_color=fondo_etiquetas_marcadors,font=('Quicksand',25,'bold'),wraplength=450,border_width=4,border_color=elige_colores[P1['color']])
    label_marcador_P2_numero_preguntas.configure(fg_color=fondo_etiquetas_marcadors,font=('Quicksand',25,'bold'),wraplength=450,border_width=4,border_color=elige_colores[P1['color']])
    label_marcador_P3_Aciertos.configure(text=f"Aciertos\n{P1['aciertos']}",fg_color=fondo_etiquetas_marcadors,font=('Quicksand',25,'bold'),wraplength=450,border_width=4,border_color=verde_andaluz)
    label_marcador_P3_Fallos.configure(text=f"Fallos\n{P1['fallos']}",fg_color=fondo_etiquetas_marcadors,font=('Quicksand',25,'bold'),border_width=4,border_color='red')
    label_marcador_P4_Categorias.configure(fg_color=fondo_etiquetas_marcadors,font=('Quicksand',25,'bold'),wraplength=450,border_width=4,border_color=elige_colores[P1['color']])
    
# **************************************************************************Importación por lotes*******************************************************************************************
def import_lotes_and_copy_json_to_root():
    lista_csv=[]
    ruta_total=[]
    lista_cat=[]
    lista_cat_json=[]
    lista_preg_resp=[]
    global label_no_hay_categorias
    global contar_preguntas
    d_pregu_respu={}
    ruta=filedialog.askdirectory()
    contenido=os.listdir(ruta)
    for file in contenido:
        if file.endswith('.csv'):
            lista_csv.append(file)
    for i in range(len(lista_csv)):
        ruta_total.append(os.path.join(ruta,lista_csv[i]))
    for i in range(len(lista_csv)):
        name_cat_no_ending_csv=lista_csv[i].replace('.csv','')
        name_cat_ending_json=lista_csv[i].replace('.csv','.json')
        lista_cat.append(name_cat_no_ending_csv)
        lista_cat_json.append(name_cat_ending_json)
    for i in range(len(ruta_total)):
        with open(ruta_total[i],'r') as fhand:
            lista_preg_resp=[]
            for line in fhand:
                line=line.rstrip().split(',')
                d_pregu_respu={'cat':lista_cat[i],'pregunta':line[0],'respuestas':line[1:]}
                lista_preg_resp.append(d_pregu_respu)
            with open(os.path.join(carpeta_json,f'{lista_cat[i]}.json'),'w',encoding='utf-8') as fhand2:
                json.dump(lista_preg_resp,fhand2)
    actualizar_scrolleable_en_configuracion()
# **************************************************************función para borrar las categorias seleccionadas en la configuración******************************************
def borrar_categorias():
    global lista_check_boxes
    global label_no_hay_categorias
    global contar_preguntas
    lista_borrar_categorias=[]
    lista_borradas_con_json=[]
    for x in lista_check_boxes:
        if x.get()==1:
            lista_borrar_categorias.append(x.cget('text'))
    for i in range(len(lista_borrar_categorias)):
        lista_borradas_con_json.append(lista_borrar_categorias[i]+'.json')
    for x in lista_borradas_con_json:
        os.remove(os.path.join(carpeta_json,x))
    actualizar_scrolleable_en_configuracion()
# **************************************************************funciones de los botones de frame_welcome******************************************
def check_for_json():#Comprueba si hay json guardados ya en la carpeta correspondiente por defecto para guardar los json
    file_json=[]#esta función se ejecuta al pulsar el botón jugar. Si funciona se pasa al juego, y si no hay json se manda a configuración
    contenido=os.listdir(carpeta_json)#al jugador para añadir categorias extraidas de los archivos csv
    for file in contenido:
        if file.endswith('.json'):
            file_json.append(file)
    if not file_json==[]:
        return True
    else:
        return False
def rutina_1_jugador():
    global players_data
    P1=players_data[0]
    colcar_transition_frame()
    frame_info_1_jugador.tkraise()
    label_ready_player_one.configure(text='Cuando pulses el botón empezará el juego.',wraplength=350,text_color='black',fg_color='white',font=('Quicksand',25,'bold'),corner_radius=8)
    button_ready_player_one.configure(text=f"Ready {P1['nombre']}?\nPulsa aquí para empezar.",height=100,text_color='black',fg_color=verde_andaluz,font=('Quicksand',25,'bold'),corner_radius=8,border_width=8,border_color=verde_andaluz,hover_color='white',command=go_questions)
    label_marcador_P2_numero_preguntas.configure(text=f"Preguntas totales:{total_de_preguntas_por_partida}")
def click_jugar():
    if check_for_json():
        label_if_not_json.grid_remove()
        frame_inicio.tkraise()
        activar_scrolleables()
        entrada_nombre_player1.focus()
        root.focus()
    else:
        label_if_not_json.grid(row=5, column=0, sticky='we', padx=100, pady=5)
        label_if_not_json.configure(text='Es necesario al menos una categoria para jugar. Selecciona la carpeta de los CSVs desde Configuración.',wraplength=850,text_color='white',fg_color=verde_andaluz,font=('Quicksand',30,'bold'),corner_radius=8)
def go_to_config():
    frame_config.place(relx=0.5,rely=0.5,anchor='center',relwidth=0.90,relheight=0.5,)
    button_añadir_categ.grid_configure(row=1,column=0,sticky='we',padx=100,pady=5)
    button_quitar_categ.grid_configure(row=2,column=0,sticky='we',padx=100,pady=5)
    button_actualizaciones.grid_configure(row=3,column=0,sticky='we',padx=100,pady=5)
    button_otra_cosa_2.grid_configure(row=4,column=0,sticky='we',padx=100,pady=5)
    frame_config.tkraise()
    etiqueta_logo.grid_remove()
def go_to_menu_bienvenida():
    frame_config.place_forget()
    label_if_not_json.grid_remove()
    etiqueta_logo.grid()
def go_to_bienvenida_from_game():
    frame_welcome.tkraise()
    reset_data_frame_inicio()
    reset_data_frame_quizz()
def preguntas_totales_partida():
    global content_all_files_json
    result=0
    for categorias in content_all_files_json:
        for preguntas in categorias:
            result+=1
    return result
def go_questions():
    reset_countdown()
    global countdown_start_numero
    global content_all_files_json
    global mi_categoria_final
    global mi_pregunta_final
    global respuesta_correcta
    global mi_pregunta_d
    global players_data
    global count_wrong_answers
    global pregunta_actual
#     **********************Modo de juego---Límite de fallos máximo establecido.Alcanzarlo lleva al fin de juego.******************************
    P1=players_data[0]
    if count_wrong_answers==limites_errores_juego():
        label_question.configure(text=f"{P1['nombre'].upper()}\nDemasiados fallos\nInténtalo de nuevo.",font=('Quicksand',50,'bold'),wraplength=700,fg_color='black',text_color='red')
        activar_botones_frame_juego()
        boton_left_up.configure(text='Jugar de nuevo.',fg_color='yellow',text_color='red',font=('Quicksand',30,'bold'),command=go_to_bienvenida_from_game)
        boton_left_down.configure(text='Jugar de nuevo.',fg_color='yellow',text_color='red',font=('Quicksand',30,'bold'),command=go_to_bienvenida_from_game)
        boton_right_up.configure(text='Jugar de nuevo.',fg_color='yellow',text_color='red',font=('Quicksand',30,'bold'),command=go_to_bienvenida_from_game)
        boton_right_down.configure(text='Jugar de nuevo.',fg_color='yellow',text_color='red',font=('Quicksand',30,'bold'),command=go_to_bienvenida_from_game)
        frame_juego.tkraise()
        frame_info_1_jugador.place_forget()
        return
#     **********************Modo de juego---Agotar respuestas de las categorias seleccionadas lleva a fin de juego.******************************
    if content_all_files_json==[]:
        label_question.configure(text='Se acabo el juego.\nNo quedan preguntas.',font=('Quicksand',50,'bold'),wraplength=700,fg_color='black',text_color='red')
        activar_botones_frame_juego()
        boton_left_up.configure(text='Jugar de nuevo.',fg_color='yellow',text_color='red',font=('Quicksand',30,'bold'),command=go_to_bienvenida_from_game)
        boton_left_down.configure(text='Jugar de nuevo.',fg_color='yellow',text_color='red',font=('Quicksand',30,'bold'),command=go_to_bienvenida_from_game)
        boton_right_up.configure(text='Jugar de nuevo.',fg_color='yellow',text_color='red',font=('Quicksand',30,'bold'),command=go_to_bienvenida_from_game)
        boton_right_down.configure(text='Jugar de nuevo.',fg_color='yellow',text_color='red',font=('Quicksand',30,'bold'),command=go_to_bienvenida_from_game)
        frame_juego.tkraise()
        frame_info_1_jugador.place_forget()
        return
    select_categoria=random.choice(content_all_files_json)#  elegir la categoria con todas sus preguntas y respuestas al azar y guardarla en la variable mi_pregunta_d
#     print(content_all_files_json)
    mi_pregunta_d=random.choice(select_categoria) #ahora estoy seleccionando la pregunta y sus respuestas dentro de la categoria que ha sido elegida anteriormente
    select_categoria.remove(mi_pregunta_d)#va borrando cada pregunta que es formulada de la lista original
    if select_categoria==[]:
         content_all_files_json.remove(select_categoria)  
    mi_categoria_final=mi_pregunta_d['cat']#aquí extraigo la categoria a la que pertenece la pregunta
    mi_pregunta_final=mi_pregunta_d['pregunta']# extraer la pregunta del diccionario y guardarla en la variable mi_pregunta_final
    respuesta_correcta=mi_pregunta_d['respuestas'][0]#extraer la respuesta correcta y guardarla en la variable respuesta_correcta
    random.shuffle(mi_pregunta_d['respuestas'])# mezclar las respuestas usando shuffle (recordar que modifica la lista directamente y no devuelve ningún valor)
#     *********************Actualizo la etiqueta y los botones con el contenido de los json****************************
#     label_question.configure(text=f'Categoría:{mi_categoria_final}\n{mi_pregunta_final}',text_color='black',fg_color=fondo_label_question,font=('Quicksand',40,'bold'),wraplength=700)border_color='white',border_width=12)
    label_question.configure(text=f'{mi_pregunta_final}',text_color='black',fg_color=fondo_label_question,font=('Quicksand',40,'bold'),wraplength=700,border_color='white',border_width=12)
    activar_botones_frame_juego()
    pregunta_actual+=1
    boton_left_up.configure(text=mi_pregunta_d['respuestas'][0],text_color='black',fg_color='white',font=('Quicksand',25,'bold'),corner_radius=8,border_width=8,border_color=verde_andaluz,hover_color=verde_andaluz,command=check_answer_BLU)
    boton_left_down.configure(text=mi_pregunta_d['respuestas'][1],text_color='black',fg_color='white',font=('Quicksand',25,'bold'),corner_radius=8,border_width=8,border_color=verde_andaluz,hover_color=verde_andaluz,command=check_answer_BLD)
    boton_right_up.configure(text=mi_pregunta_d['respuestas'][2],text_color='black',fg_color='white',font=('Quicksand',25,'bold'),corner_radius=8,border_width=8,border_color=verde_andaluz,hover_color=verde_andaluz,command=check_answer_BRU)
    boton_right_down.configure(text=mi_pregunta_d['respuestas'][3],text_color='black',fg_color='white',font=('Quicksand',25,'bold'),corner_radius=8,border_width=8,border_color=verde_andaluz,hover_color=verde_andaluz,command=check_answer_BRD)
    supercat=mi_categoria_final.upper()
    label_marcador_P2_numero_preguntas.configure(text=f"Pregunta\n{pregunta_actual}/{total_de_preguntas_por_partida}")
    label_marcador_P4_Categorias.configure(text=f"Categoría: {supercat}")
    frame_juego.tkraise()
    frame_info_1_jugador.place_forget()
    if limite_tiempo_partida==False:
        label_countdown.configure(image=logo_ctk_countdown,text='')
    else:
        countdown()
    return mi_categoria_final,mi_pregunta_final,respuesta_correcta,mi_pregunta_d['respuestas']
# ******************************************************función de comprobación de las respuestas
estadistica_total=[]
def check_answers(boton_pulsado):
    fecha=datetime.now().strftime('%d/%m/%Y\n%H:%M')
    global estadistica_total
    global respuesta_correcta
    global count_right_answers
    global count_wrong_answers
    global players_data
    global  identificador_countdown
    global limite_tiempo_partida
    P1=players_data[0]
    right_answer=respuesta_correcta.upper()
    desactivar_botones_frame_juego()
    if limite_tiempo_partida:
        root.after_cancel(identificador_countdown)
    if boton_pulsado.cget('text')==respuesta_correcta:
        count_right_answers+=1
        players_data[0]['aciertos']=count_right_answers
        label_marcador_P3_Aciertos.configure(text=f"Aciertos\n{P1['aciertos']}")#,fg_color='light green',font=('Quicksand',25,'bold'),wraplength=450)
        colcar_transition_frame()
        frame_info_1_jugador.tkraise()
        win1,win2=win_animos()
        label_ready_player_one.configure(text=f'{win1}\n{right_answer} era la respuesta correcta.\n {win2}',wraplength=350,text_color='black',fg_color='white',font=('Quicksand',25,'bold'),corner_radius=8)
        button_ready_player_one.configure(text='Siguiente Pregunta',height=100,text_color='black',fg_color=verde_andaluz,font=('Quicksand',25,'bold'),corner_radius=8,border_width=8,border_color=verde_andaluz,hover_color='white',command=go_questions)
    else:
        count_wrong_answers+=1
        players_data[0]['fallos']=count_wrong_answers
        label_marcador_P3_Fallos.configure(text=f"Fallos\n{P1['fallos']}")#,fg_color='red',font=('Quicksand',25,'bold'))
        colcar_transition_frame()
        frame_info_1_jugador.tkraise()
        lose1,lose2=lose_animos()
        estadistica_juego={'Fecha':fecha,'Nombre':P1['nombre'].upper(),'Categoria':mi_categoria_final,'Pregunta_Fallada':mi_pregunta_final,'Respuesta_dada':boton_pulsado.cget('text')}
        estadistica_total.append(estadistica_juego)
        label_ready_player_one.configure(text=f'{lose1}\n La respuesta correcta era {right_answer}.\n{lose2}',wraplength=350,text_color='black',fg_color='white',font=('Quicksand',25,'bold'),corner_radius=8)
        button_ready_player_one.configure(text='Siguiente Pregunta',height=100,text_color='black',fg_color=verde_andaluz,font=('Quicksand',25,'bold'),corner_radius=8,border_width=8,border_color=verde_andaluz,hover_color='white',command=go_questions)
def win_animos():
    congrats = ['¡Enhorabuena!', '¡Felicidades!','¡Bien hecho!', '¡Genial!', '¡Excelente!', '¡Perfecto!', '¡Bravo!', '¡Estupendo!', '¡Fantástico!', '¡Lo has clavado!']
    winner_animos=['¡Vamos a por la siguiente!', '¡A por otra!', '¡Sigamos jugando!', '¡Vamos con la próxima!', '¡A por más!', '¡Seguimos!', '¡Otra pregunta más!', '¡No pares ahora!', '¡Vamos allá de nuevo!', '¡A por la revancha!']
    return random.choice(congrats),random.choice(winner_animos)
def lose_animos():
    you_fail = ['¡Fallaste!', '¡Casi!', '¡Qué pena!', '¡La próxima será!', '¡Sigue intentándolo!', '¡No ha sido esta vez!', '¡Vaya, fallo!', '¡Un poco más de suerte la próxima vez!', '¡Ánimo, sigue así!', '¡Esta vez no ha podido ser!']
    loser_animos = ['¡Atento con la siguiente!', '¡Concéntrate en la próxima!', '¡A por la siguiente, con ganas!', '¡Ojo con la próxima pregunta!', '¡Fíjate bien en la siguiente!', '¡Vamos, que la próxima es tuya!', '¡Con más atención esta vez!', '¡A la siguiente con más fuerza!', '¡Recupera terreno en la próxima!', '¡Ánimo con la que viene!']
    return random.choice(you_fail),random.choice(loser_animos)
def desactivar_botones_frame_juego():
    lista_botones=[boton_left_up,boton_left_down,boton_right_up,boton_right_down]
    for i in range(len(lista_botones)):
        lista_botones[i].configure(state='disabled')
def activar_botones_frame_juego():
    lista_botones=[boton_left_up,boton_left_down,boton_right_up,boton_right_down]
    for i in range(len(lista_botones)):
        lista_botones[i].configure(state='normal')
def reset_data_frame_inicio():
    global indice_inicio_P1
    global nameP1
    global players_data
    global count_right_answers
    global count_wrong_answers
    global pregunta_actual
    pregunta_actual=0
    indice_inicio_P1=-1
    nameP1=''
    players_data=[]
    count_right_answers=0
    count_wrong_answers=0
    entrada_nombre_player1.delete(0,'end')
    boton_color_choice_P1.configure(state='disabled',text='Elige aquí tu color',font=('Quicksand',25,'bold'),corner_radius=8,height=70,text_color='black',fg_color='white',hover=False,command=color_choice_P1)
    boton_color_choice_P1.configure(state='normal',text='Elige aquí tu color',font=('Quicksand',25,'bold'),height=70,corner_radius=8,text_color='black',fg_color='white',hover=False,command=color_choice_P1)
    entrada_nombre_player1.configure(state='normal',placeholder_text='Escribe aquí tu nombre',placeholder_text_color='black',font=('Quicksand',25,'bold'),corner_radius=8,fg_color='white',height=70,width=300)#cambiar el estado del color afecta al estado del widget. Es como una banderita que le dice
    boton_start_game.configure(state='disabled',text='',fg_color='transparent')
    reset_botones_limites_a_10()
    # Limpiar mensaje de advertencia
    label_warning.configure(text='',fg_color='transparent')
def reset_data_frame_quizz():
    global pregunta_actual
    pregunta_actual=0
    label_question.configure(text='Pregunta',font=('Quicksand',40,'bold'),wraplength=700,fg_color=fondo_label_question,border_color='white',border_width=12)
    boton_left_up.configure(text='Respuesta',text_color='black',fg_color=verde_andaluz,font=('Quicksand',25,'bold'),corner_radius=8,border_width=8,border_color=verde_andaluz,hover_color='white',state='disabled')
    boton_left_down.configure(text='Respuesta',text_color='black',fg_color=verde_andaluz,font=('Quicksand',25,'bold'),corner_radius=8,border_width=8,border_color=verde_andaluz,hover_color='white',state='disabled')
    boton_right_up.configure(text='Respuesta',text_color='black',fg_color=verde_andaluz,font=('Quicksand',25,'bold'),corner_radius=8,border_width=8,border_color=verde_andaluz,hover_color='white',state='disabled')
    boton_right_down.configure(text='Respuesta',text_color='black',fg_color=verde_andaluz,font=('Quicksand',25,'bold'),corner_radius=8,border_width=8,border_color=verde_andaluz,hover_color='white',state='disabled')
    reset_botones_limites_a_10()
def reset_botones_limites_a_10(): 
    lista_botones_limites=[boton_10_errores,boton_10_segundos,boton_5_errores,boton_5_segundos,boton_3_errores,boton_3_segundos,boton_inf_errores,boton_inf_segundos]
    lista_limites_10=[boton_10_errores,boton_10_segundos]
    for x in lista_botones_limites:
        x.configure(fg_color=fondo_botones_limites)
    for x in lista_limites_10:
        x.configure(fg_color=verde_andaluz)
#     label_countdown.configure(text='Cuenta atrás',fg_color='black',text_color='white',width=250)
# ************************************************************************funciones del checkbox***************************************************************************
marcar_botones_todos=0
def marcar_todos_checkboxes():
    global  marcar_botones_todos
    if marcar_botones_todos==0:
        for checkbox in lista_check_boxes:
            checkbox.select()
            marcar_botones_todos=1
    else:
        for checkbox in lista_check_boxes:
            checkbox.deselect()
            marcar_botones_todos=0
# ******************************************Funciones puente-Son las que se llaman con command desde los botones de respuesta*******************************************
def check_answer_BRU():
    check_answers(boton_right_up)
def check_answer_BRD():
    check_answers(boton_right_down)
def check_answer_BLU():
   check_answers(boton_left_up)
def check_answer_BLD():
    check_answers(boton_left_down)
def colcar_transition_frame():#esta función vuelve a colocar el frame_info_player_one en su sitio dado que con .place_forget lo eliminaba por completo del mapa
    frame_info_1_jugador.place(relx=0.5,rely=0.5,anchor='center',relwidth=0.7,relheight=0.5,y=-100)
mensaje_warning=False
def activar_scrolleables():
    global mensaje_warning
#     paso 1-Comprobar la lista de checkboxes previa para eliminar los checkboxes que hayan sido creados prieviamente.
    lista_categorias_sinjson=[]
    file_json=[]
    global lista_check_boxes
    for x in lista_check_boxes:
        x.grid_forget()
    if mensaje_warning==True:
        label_no_hay_categorias.grid_forget()
    lista_check_boxes=[]
    contenido=os.listdir(carpeta_json)
    for file in contenido:
        if file.endswith('.json'):
            file_json.append(file)
    for i in range(len(file_json)):
        lista_sinjson=file_json[i].replace('.json','')
        lista_categorias_sinjson.append(lista_sinjson)#esta la lista que contiene las categorias actuales
    if file_json==[]:
        label_no_hay_categorias=ctk.CTkLabel(mi_panel_scrollable,text='No se han encontrado categorías.\nPara añadir categorias vaya a Configuración.')
        label_no_hay_categorias.grid(row=2,column=0,columnspan=4)
        mensaje_warning=True
    else:
        patata=sorted(lista_categorias_sinjson,key=str.lower)#una forma de ordenar alfabéticamente, sin tener en cuenta las minúsculas (hay otra forma de hacerlo, y se ha utilizado en el otro panel scrolleable)
        for i in range(len(lista_categorias_sinjson)):
            mi_checkbox= ctk.CTkButton(mi_panel_scrollable,text=patata[i]
            ,fg_color=fondo_botones_scrolleable_select_colores,text_color='black',border_width= 2,border_color='white',
            font=('Quicksand',25,'bold'),hover_color='yellow')
            mi_checkbox.configure(command=lambda boton=mi_checkbox:cambia_color_boton_categorias_scrolleable(boton))
            mi_checkbox.grid(row=(i+4)//4, column=i%4, sticky='w', pady=5)
            lista_check_boxes.append(mi_checkbox)
        mensaje_warning=False
countdown_start_numero=limite_tiempo_partida#esto pertenece a la función countdown y es donde empieza la cuenta atrás
def cambia_color_boton_categorias_scrolleable(boton):
    global lista_check_boxes
    if boton.cget('fg_color')==fondo_botones_scrolleable_select_colores:
        boton.configure(fg_color='yellow')
    else:
        boton.configure(fg_color=fondo_botones_scrolleable_select_colores)
def marcar_botones_categorias():
    global lista_check_boxes
    if any(x.cget('fg_color')==fondo_botones_scrolleable_select_colores for x in lista_check_boxes):
        for x in lista_check_boxes:
            x.configure(fg_color='yellow')
    else:
        for x in lista_check_boxes:
            x.configure(fg_color=fondo_botones_scrolleable_select_colores)
def countdown():
    global respuesta_correcta
    global countdown_start_numero
    global count_wrong_answers
    global players_data
    global identificador_countdown
    right_answer=respuesta_correcta.upper()
    if countdown_start_numero<0:
        desactivar_botones_frame_juego()
        label_countdown.configure(text="Tiempo\nagotado",font=('Quicksand',50,'bold'),width=250,border_color='white')
        count_wrong_answers+=1
        players_data[0]['fallos']=count_wrong_answers
        P1=players_data[0]
        label_marcador_P3_Fallos.configure(text=f"Fallos\n{P1['fallos']}")
        colcar_transition_frame()
        frame_info_1_jugador.tkraise()
        lose1,lose2=lose_animos()
        label_ready_player_one.configure(text=f'{lose1}\n La respuesta correcta era {right_answer}.\n{lose2}',wraplength=350,text_color='black',fg_color='white',
                                         font=('Quicksand',25,'bold'),corner_radius=8)
        button_ready_player_one.configure(text='Siguiente Pregunta',height=100,text_color='black',fg_color=verde_andaluz,font=('Quicksand',25,'bold'),corner_radius=8,border_width=8,
                                          border_color=verde_andaluz,hover_color='white',command=go_questions)
        return
    if countdown_start_numero>=7:
        label_countdown.configure(text=countdown_start_numero,fg_color='black',text_color=verde_andaluz,font=('Quicksand',150,'bold'),width=250)
        countdown_start_numero-=1
    elif countdown_start_numero>=4 and countdown_start_numero<7:
        label_countdown.configure(text=countdown_start_numero,fg_color='black',text_color='yellow',font=('Quicksand',150,'bold'),width=250)
        countdown_start_numero-=1
    elif countdown_start_numero>=0 and countdown_start_numero<4:
        label_countdown.configure(text=countdown_start_numero,fg_color='black',text_color='red',font=('Quicksand',150,'bold'),width=250)
        countdown_start_numero-=1
    identificador_countdown=root.after(1000,countdown)
def reset_countdown():
    global countdown_start_numero
    if limite_tiempo_partida==False:
        countdown_start_numero=limite_tiempo_partida
        activar_botones_frame_juego()
    else:
        countdown_start_numero=limite_tiempo_partida
        activar_botones_frame_juego()
        label_countdown.configure(image='',text=countdown_start_numero,fg_color='black',text_color='white',font=('Quicksand',50,'bold'),width=250)
def scrolleables_add_del_categorias():
    button_añadir_categ.configure(state='disabled')
    
    global scrollable_add_del_categorias
    scrollable_add_del_categorias = ctk.CTkScrollableFrame(frame_config, label_text="Categorías existentes")
    scrollable_add_del_categorias.grid(row=2, column=0,rowspan=8,columnspan=5,sticky='nsew')
    scrollable_add_del_categorias.grid_columnconfigure(0,minsize=200,weight=1)
    scrollable_add_del_categorias.grid_columnconfigure(1,minsize=200, weight=1)
    scrollable_add_del_categorias.grid_columnconfigure(2,minsize=200, weight=1)
    scrollable_add_del_categorias.grid_columnconfigure(3,minsize=200, weight=1)
    scrollable_add_del_categorias.configure(label_font=('Quicksand',20,'bold'),label_fg_color=verde_andaluz,fg_color='white',border_width=4,border_color=verde_andaluz)

    # ********************************botón de seleccionar todos/deseleccionar todos************************************
    boton_marcar_todos=ctk.CTkButton(scrollable_add_del_categorias,text='Marcar Todo\nDesmarcar todo')
    boton_marcar_todos.grid(row=0, column=1, sticky='we', pady=5,padx=5)
    boton_marcar_todos.configure(command=marcar_todos_checkboxes,font=('Quicksand',15,'bold'),text_color='black',hover_color=verde_andaluz,fg_color=fondo_boton_scrolleable_config,
                                 border_width=4,border_color=verde_andaluz)
    # ********************************botón de añadir CSV************************************
    boton_add_categorias=ctk.CTkButton(scrollable_add_del_categorias,text="Añadir\nCSV")
    boton_add_categorias.grid(row=0, column=0, sticky='we', pady=5,padx=5)
    boton_add_categorias.configure(command=import_lotes_and_copy_json_to_root,font=('Quicksand',15,'bold'),text_color='black',hover_color=verde_andaluz,fg_color=fondo_boton_scrolleable_config,
                                   border_width=4,border_color=verde_andaluz)
    # ********************************botón de eliminar categorías************************************
    boton_del_categoria=ctk.CTkButton(scrollable_add_del_categorias,text='Eliminar\nSeleccionadas')
    boton_del_categoria.grid(row=0, column=2, sticky='we', pady=5,padx=5)
    boton_del_categoria.configure(fg_color=fondo_boton_scrolleable_config,border_width=4,border_color='red',font=('Quicksand',15,'bold'),text_color='black',hover_color='red',command=borrar_categorias)
    # ********************************botón de volver a configuración************************************
    boton_voler_menu_config=ctk.CTkButton(scrollable_add_del_categorias,text='Volver\nConfiguración')
    boton_voler_menu_config.grid(row=0, column=3, sticky='we', pady=5,padx=5)
    boton_voler_menu_config.configure(fg_color=fondo_boton_scrolleable_config,border_width=4,border_color=verde_andaluz,hover_color=verde_andaluz,font=('Quicksand',15,'bold'),
                                      text_color='black',command=config_from_scroll_add_actegorias)
    global mensaje_warning
    global label_no_hay_categorias
#     paso 1-Comprobar la lista de checkboxes previa para eliminar los checkboxes que hayan sido creados prieviamente.
    lista_categorias_sinjson=[]
    file_json=[]
    global lista_check_boxes
    actualizar_scrolleable_en_configuracion()
def config_from_scroll_add_actegorias():
    global scrollable_add_del_categorias
    scrollable_add_del_categorias.grid_remove()
    button_añadir_categ.configure(state='normal')
# *********************************************************************************funcion actualizar scrolleable**********************************************************
def actualizar_scrolleable_en_configuracion():
    global mensaje_warning
    lista_categorias_sinjson=[]
    file_json=[]
    global lista_check_boxes
    global label_no_hay_categorias
    for x in lista_check_boxes:
        x.grid_forget()
    if mensaje_warning==True:
        label_no_hay_categorias.grid_forget()
    lista_check_boxes=[]
    contenido=os.listdir(carpeta_json)
    for file in contenido:
        if file.endswith('.json'):
            file_json.append(file)
    for i in range(len(file_json)):
        lista_sinjson=file_json[i].replace('.json','')
        lista_categorias_sinjson.append(lista_sinjson)#esta es la lista que contiene las categorias actuales
    lista_categorias_sinjson.sort(key=str.lower) #una forma de ordenar alfabéticamente, sin tener en cuenta las minúsculas (hay otra forma de hacerlo, y se ha utilizado en el otro panel scrolleable)
    if file_json==[]:
        label_no_hay_categorias=ctk.CTkLabel(mi_panel_scrollable,text='No se han encontrado categorías.\nPara añadir categorias vaya a Configuración.')
        label_no_hay_categorias.grid(row=2,column=0,columnspan=4)
        mensaje_warning=True
    else:
        for i in range(len(lista_categorias_sinjson)):
            mi_checkbox= ctk.CTkCheckBox(scrollable_add_del_categorias,text=lista_categorias_sinjson[i],fg_color=verde_andaluz,font=('Quicksand',20,'bold'))
            mi_checkbox.grid(row=(i+4)//4, column=i%4, sticky='w', pady=5)
            lista_check_boxes.append(mi_checkbox)
        mensaje_warning=False
def go_to_bienvenida_from_inicio():
    frame_welcome.tkraise()
    reset_data_frame_inicio()
identificador_countdown = None
def go_to_bienvenida_from_game_questions():
    P1=players_data[0]
    global identificador_countdown
    global countdown_start_numero
    if identificador_countdown==None:
        frame_welcome.tkraise()
        reset_data_frame_inicio()
        reset_data_frame_quizz()
        countdown_start_numero=10
        label_countdown.configure(image='',text=countdown_start_numero,fg_color='black',text_color='white',font=('Quicksand',50,'bold'),width=250)
        label_marcador_P4_Categorias.configure(text='Categoría Actual')
    else:
        root.after_cancel(identificador_countdown)
        frame_welcome.tkraise()
        reset_data_frame_inicio()
        reset_data_frame_quizz()
        countdown_start_numero=10
        label_countdown.configure(image='',text=countdown_start_numero,fg_color='black',text_color='white',font=('Quicksand',50,'bold'),width=250)
        label_marcador_P4_Categorias.configure(text='Categoría Actual')
# *********************************************************************CONTROL COLOR DE BOTONES DE LÍMITES DE TIEMPO Y ERRORES**********************************************************************************************************
# ****************************************************************************FRAME INICIO***************************************************************************************************       
def cambia_color_boton_3_errores():
    boton=boton_3_errores
    botones_del_limite_errores_copia=botones_del_limite_errores.copy()
    if boton.cget('fg_color')!=verde_andaluz:
        boton.configure(fg_color=verde_andaluz)
        botones_del_limite_errores_copia.remove(boton)
        for x in botones_del_limite_errores_copia:
            x.configure(fg_color=fondo_botones_limites)
def cambia_color_boton_5_errores():
    boton=boton_5_errores
    botones_del_limite_errores_copia=botones_del_limite_errores.copy()
    if boton.cget('fg_color')!=verde_andaluz:
        boton.configure(fg_color=verde_andaluz)
        botones_del_limite_errores_copia.remove(boton)
        for x in botones_del_limite_errores_copia:
            x.configure(fg_color=fondo_botones_limites)
def cambia_color_boton_10_errores():
    boton=boton_10_errores
    botones_del_limite_errores_copia=botones_del_limite_errores.copy()
    if boton.cget('fg_color')!=verde_andaluz:
        boton.configure(fg_color=verde_andaluz)
        botones_del_limite_errores_copia.remove(boton)
        for x in botones_del_limite_errores_copia:
            x.configure(fg_color=fondo_botones_limites)
def cambia_color_boton_inf_errores():
    boton=boton_inf_errores
    botones_del_limite_errores_copia=botones_del_limite_errores.copy()
    if boton.cget('fg_color')!=verde_andaluz:
        boton.configure(fg_color=verde_andaluz)
        botones_del_limite_errores_copia.remove(boton)
        for x in botones_del_limite_errores_copia:
            x.configure(fg_color=fondo_botones_limites)
def cambia_color_boton_3_segundos():
    boton=boton_3_segundos
    botones_del_limite_segundos_copia=botones_del_limite_segundos.copy()
    if boton.cget('fg_color')!=verde_andaluz:
        boton.configure(fg_color=verde_andaluz)
        botones_del_limite_segundos_copia.remove(boton)
        for x in botones_del_limite_segundos_copia:
            x.configure(fg_color=fondo_botones_limites)
def cambia_color_boton_5_segundos():
    boton=boton_5_segundos
    botones_del_limite_segundos_copia=botones_del_limite_segundos.copy()
    if boton.cget('fg_color')!=verde_andaluz:
        boton.configure(fg_color=verde_andaluz)
        botones_del_limite_segundos_copia.remove(boton)
        for x in botones_del_limite_segundos_copia:
            x.configure(fg_color=fondo_botones_limites)
def cambia_color_boton_10_segundos():
    boton=boton_10_segundos
    botones_del_limite_segundos_copia=botones_del_limite_segundos.copy()
    if boton.cget('fg_color')!=verde_andaluz:
        boton.configure(fg_color=verde_andaluz)
        botones_del_limite_segundos_copia.remove(boton)
        for x in botones_del_limite_segundos_copia:
            x.configure(fg_color=fondo_botones_limites)
def cambia_color_boton_inf_segundos():
    boton=boton_inf_segundos
    botones_del_limite_segundos_copia=botones_del_limite_segundos.copy()
    if boton.cget('fg_color')!=verde_andaluz:
        boton.configure(fg_color=verde_andaluz)
        botones_del_limite_segundos_copia.remove(boton)
        for x in botones_del_limite_segundos_copia:
            x.configure(fg_color=fondo_botones_limites)
# *******************************************************Obtener límite errores en el juego*********************************************************           
# ****************************************************Se implementa en check_before_start**********************************************************
def limites_errores_juego():
    if boton_3_errores.cget('fg_color')==verde_andaluz:
        return 3
    elif boton_5_errores.cget('fg_color')==verde_andaluz:
        return 5
    elif boton_10_errores.cget('fg_color')==verde_andaluz:
        return 10
    elif boton_inf_errores.cget('fg_color')==verde_andaluz:
        return None
# *******************************************************Obtener límite tiempo en el juego*********************************************************
# ****************************************************Se implementa en check_before_start**********************************************************
def limites_tiempo_juego():
    if boton_3_segundos.cget('fg_color')==verde_andaluz:
        return 3
    elif boton_5_segundos.cget('fg_color')==verde_andaluz:
        return 5
    elif boton_10_segundos.cget('fg_color')==verde_andaluz:
        return 10
    elif boton_inf_segundos.cget('fg_color')==verde_andaluz:
        return False
    
    
# ***********************************************************************Actualizador**************************************************************************
import urllib.request
import subprocess
# **************Comprobar versión del programa*************
url_check_version=('https://raw.githubusercontent.com/nico-enred/Updater/refs/heads/main/Version_check')
def check_version():
    inside_url_origen=[]
    fhand=urllib.request.urlopen(url_check_version)
    for line in fhand:
        line=line.decode().strip()
        inside_url_origen.append(line)
    fhand.close()
    return inside_url_origen
in_url_origen=check_version()#llamamos la función para tener su return disponible como parametro

def extract_content_from_url_origin(in_url_origen):#extraígo el contenido de la url.
    new_version=in_url_origen[0]#La nueva versión que está en la primera línea
    downloading_new_file_url=in_url_origen[1]#La url del archivo nuevo para descargar
    modifications=in_url_origen[3:]#Las modificaciones que contiene el nuevo programa. De la tercera línea en adelante
    return new_version,downloading_new_file_url,modifications

new_version,downloading_new_file_url,modifications=extract_content_from_url_origin(in_url_origen)#Se llama la función para tener disponibles las variables
                                                                                                
def get_current_version():#Obtenemos la versión actual del archivo del archivo current_version.txt
    with open(os.path.join(carpeta_base,'current_version.txt'),'r') as fhand2:
        for line in fhand2:
            return line.strip()#it exists after reading the first line. if ever were added more lines the return should move out of the loop.
        
current_version=get_current_version()
def change_to_new_version_in_currrent_version(new_version):#Cambiar version en current_version.txt
    with open(os.path.join(carpeta_base,'current_version.txt'),'w') as fhand3:
        fhand3.write(new_version)
        
def download_new_file(downloading_new_file_url):#Descargar archivo nuevo desde la url que hay en la segunda posición
    data=urllib.request.urlopen(downloading_new_file_url).read()
    with open(os.path.join(carpeta_base,'New_Ahorcado.py'),'wb') as fhand4:
        fhand4.write(data)

# ***************terminate program and start new one***************************************
def terminate_program(): #to be run on the program itself to delete after all the checks
    sys.exit()
def start_updater():
    if getattr(sys, 'frozen', False):
        subprocess.Popen([Updater_ruta_absoluta])#after checking there is a new version in the old program, it starts the updater
    else:
        subprocess.Popen(['python3',Updater_ruta_absoluta])#after checking there is a new version in the old program, it starts the updater

def actualizar():
    change_to_new_version_in_currrent_version(new_version)
    download_new_file(downloading_new_file_url)
    start_updater()
    terminate_program()

def no_actualizar():
    boton_yes.grid_remove()
    boton_no.grid_remove()
    
identificador_brilli_botones=None
def brilli_boton(boton_yes):
    global identificador_brilli_botones
    if boton_yes.cget('fg_color')=='light green':
        boton_yes.configure(fg_color='green')
    else:
        boton_yes.configure(fg_color='light green')
    identificador_brilli_botones=root.after(1000,brilli,boton_yes)
    
identificador_brilli_hay_actualizaciones=None
def brilli_hay_actualizaciones(boton_config):
    global identificador_brilli_hay_actualizaciones
    if boton_config.cget('fg_text')=='Configuración':
        boton_config.configure(fg_color='Configuración-Actualizar programa')
    else:
        boton_config.configure(fg_color='Configuración')
    identificador_brilli_hay_actualizaciones=root.after(2000,brilli,boton_config)
    
def create_widgets_update():
        frame_actualizar=ctk.CTkFrame(root,fg_color='light blue',border_color='blue',border_width=5)
        label_show_version=ctk.CTkLabel(frame_actualizar,
                                        text=f'La versión actual es:{current_version}. Hay una nueva versión disponible.\n¿Quiere actualizar?'
                                        ,fg_color='green',border_color='yellow',border_width=2)
        label_show_version.grid_configure(row=0,
                                          column=0,columnspan=3,sticky='nswe')
        label_show_modification=ctk.CTkLabel(frame_actualizar,text=f'Las modificaciones que se añadirán son:\n{modifications}')
        label_show_modification.grid_configure(row=1,
                                               column=0,columnspan=3,sticky='nswe')
        boton_yes=ctk.CTkButton(frame_actualizar,text='Actualizar',fg_color='light green',hover_color='green',command=actualizar)
        boton_yes.grid_configure(row=2
                                 ,column=0)
        boton_no=ctk.CTkButton(frame_actualizar,text='No Actualizar',fg_color='pink',hover_color='red',command=no_actualizar)
        boton_no.grid_configure(row=2,
                                column=3)
        
# *********************************************************************INTERFAZ GRÁFICA**********************************************************************************************************
verde_andaluz='#007A33'
fondo_elección_colores_jugador=fondo_panel_scrollebale_elegir_color=fondo_frame_stats_players=fondo_frame_quiz=fondo_etiquetas_marcadors='#EDB47E'
fondo_frame_transicion=color_fondo_welcome_config='#F5D5B0'
fondo_boton_scrolleable_config=fondo_boton_volver_colores_jugador=fondo_botones_limites=fondo_button_actualizaciones='#99ADBF'
fondo_label_question='#007A33'
fondo_botones_scrolleable_select_colores='#EDB47E'
# ************************************************************************************************************************************************************************************************
import customtkinter as ctk
from PIL import Image
root=ctk.CTk()
root.title('Trivial')
root.geometry('1200x1200')
root.resizable(True ,True )
ctk.set_appearance_mode('light')
# *************************************************************************Actualizar**************************************************************
if current_version!=new_version: #si se cumple la condición empezamos la actualización
    create_widgets_update()
    frame_actualizar.tkraise()
    brilli_boton(boton_yes)
    brilli_hay_actualizaciones(button_config)
# *********hago que los grid de root se expanda en columnas y filas******************************************************************************
root.rowconfigure(0,weight=1)
root.columnconfigure(0,weight=1)
# **********creo los frame **********
frame_welcome=ctk.CTkFrame(root,fg_color=color_fondo_welcome_config)
frame_inicio=ctk.CTkFrame(root)
frame_juego=ctk.CTkFrame(root)
# *********************hijo de frame_welcome********************************************************************************************************
frame_config=ctk.CTkFrame(frame_welcome,fg_color=color_fondo_welcome_config,border_width=4,border_color=verde_andaluz)
# *********************************Hijos de _FRAME_INICIO *****************************************************************************************
frame_players=ctk.CTkFrame(frame_inicio,fg_color=fondo_elección_colores_jugador)
frame_player_panel_scroll=ctk.CTkFrame(frame_inicio,fg_color=fondo_elección_colores_jugador)
frame_players_modos_juego=ctk.CTkFrame(frame_inicio,fg_color=fondo_elección_colores_jugador)
frame_botton_labels=ctk.CTkFrame(frame_inicio,fg_color=verde_andaluz)
# ***********************frame_inicio*********************************
frame_inicio.rowconfigure(0,weight=1)
frame_inicio.columnconfigure(0,weight=1)
frame_inicio.rowconfigure(1,weight=4)
frame_inicio.rowconfigure(2,weight=2)
frame_inicio.rowconfigure(3,weight=6)
# ********coloco TODOS los frame en su grid**********
frame_welcome.grid_configure(row=0,column=0,sticky='nsew')
frame_inicio.grid_configure(row=0,column=0,sticky='nsew')
frame_juego.grid_configure(row=0,column=0,sticky='nsew')
frame_players.grid_configure(row=0,column=0,sticky='nswe')
frame_player_panel_scroll.grid_configure(row=1,column=0,sticky='nswe')
frame_players_modos_juego.grid_configure(row=2,column=0,sticky='nswe')
frame_botton_labels.grid_configure(row=3,column=0,sticky='nswe')
# ***********************frame_welcome*********************************
frame_welcome.rowconfigure(0,weight=1)
frame_welcome.rowconfigure(1,weight=2)
frame_welcome.rowconfigure(6,weight=5)
frame_welcome.columnconfigure(0,weight=1)
# ***********************************************creo y coloco los widgets de cada frame******************************
# **********widgets de frame_welcome ********************
logo_PIl=Image.open(os.path.join(carpeta_imagenes,'logo.png'))
logo_ctk=ctk.CTkImage(light_image=logo_PIl,size=(500,500))
etiqueta_logo=ctk.CTkLabel(frame_welcome,text='',image=logo_ctk)
button_jugar=ctk.CTkButton(frame_welcome, text='Jugar',text_color='black',fg_color=verde_andaluz,font=('Quicksand',25,'bold'),corner_radius=8,hover_color='white',command=click_jugar)
button_config=ctk.CTkButton(frame_welcome, text='Configuración',text_color='black',fg_color=verde_andaluz,font=('Quicksand',25,'bold'),corner_radius=8,hover_color='white',command=go_to_config)
button_total_stats=ctk.CTkButton(frame_welcome, text='Estadísticas',text_color='black',fg_color=verde_andaluz,font=('Quicksand',25,'bold'),corner_radius=8,hover_color='white')
button_instructions=ctk.CTkButton(frame_welcome, text='Instrucciones',text_color='black',fg_color=verde_andaluz,font=('Quicksand',25,'bold'),corner_radius=8,hover_color='white')
label_if_not_json=ctk.CTkLabel(frame_welcome,text='',wraplength=250,font=('Quicksand',25,'bold'),corner_radius=8)
# *********grid de frame_welcome y sus widgets************
frame_welcome.grid_configure(row=0,column=0,sticky='nswe')
etiqueta_logo.grid_configure(row=1,column=0)
button_jugar.grid_configure(row=2,column=0,sticky='we',padx=250,pady=5)
button_instructions.grid_configure(row=3,column=0,sticky='we',padx=250,pady=5)
button_config.grid_configure(row=4,column=0,sticky='we',padx=250,pady=5)
button_total_stats.grid_configure(row=5,column=0,sticky='we',padx=250,pady=5)
label_if_not_json.grid_configure(row=6,column=0,sticky='we',padx=100,pady=5)
# *********************Pesos de frame_config***********
frame_config.rowconfigure(0,weight=1)
frame_config.rowconfigure(5,weight=1)
frame_config.columnconfigure(0,weight=1)
# *********widgets de frame_config *********************
button_añadir_categ=ctk.CTkButton(frame_config,state='normal', text='Añadir CSV-Eliminar Categorías',text_color='black',fg_color=verde_andaluz,font=('Quicksand',25,'bold'),
                                  corner_radius=8,hover_color='white',command=scrolleables_add_del_categorias)
button_quitar_categ=ctk.CTkButton(frame_config, text='Otra Cosa 1',text_color='black',fg_color=verde_andaluz,font=('Quicksand',25,'bold'),corner_radius=8,hover_color='white')
button_actualizaciones=ctk.CTkButton(frame_config, text='Actualizaciones',text_color='black',fg_color=button_actualizaciones,font=('Quicksand',25,'bold'),corner_radius=8,state=disabled)
button_otra_cosa_2=ctk.CTkButton(frame_config, text='Menú inicio',text_color='black',fg_color=verde_andaluz,font=('Quicksand',25,'bold'),corner_radius=8,hover_color='white',
                                 command=go_to_menu_bienvenida)
# **************************************************************hijos de frame_inicio *********************************************************************************
# ***********widgets de frame_players ********************
boton_color_choice_P1=ctk.CTkButton(frame_players,state='normal',text='Pulsa y elige color',font=('Quicksand',25,'bold'),border_color='black',border_width=1,corner_radius=8,
                                    text_color='black',height=70,fg_color='white',hover=False,command=color_choice_P1)
entrada_nombre_player1=ctk.CTkEntry(frame_players,state='normal',placeholder_text='Escribe aquí tu nombre',placeholder_text_color='black',font=('Quicksand',25,'bold'),
                                    corner_radius=8,height=70,width=300)
boton_volver_a_bienvendida=ctk.CTkButton(frame_players,text='Volver',font=('Quicksand',15,'bold'),corner_radius=8,text_color='black',fg_color=fondo_boton_volver_colores_jugador,
                                         border_width=4,border_color=verde_andaluz,hover_color='white',command=go_to_bienvenida_from_inicio)
entrada_nombre_player1.bind("<KeyRelease>",color_data_P1)
# ***********grid de widgets de frame_players************
frame_players.grid_columnconfigure(0,weight=1,minsize=100)
frame_players.grid_columnconfigure(1,weight=1,minsize=550)
frame_players.grid_columnconfigure(2,weight=1,minsize=550)
boton_volver_a_bienvendida.grid_configure(row=1,column=0,sticky='we',padx=5,pady=5)
boton_color_choice_P1.grid_configure(row=1,column=1,sticky='we',padx=10,pady=10)
entrada_nombre_player1.grid_configure(row=1,column=2,sticky='we',padx=10,pady=10)
# *******************************************************************panel scrolleable******************************************************************************
mi_panel_scrollable = ctk.CTkScrollableFrame(frame_player_panel_scroll,fg_color=verde_andaluz, label_text="Selecciona con qué categorías quieres jugar",
                                             label_font=('Quicksand',25,'bold'),label_fg_color='white',label_text_color='black')
frame_player_panel_scroll.grid_columnconfigure(0,weight=1)
frame_player_panel_scroll.grid_rowconfigure(0,weight=1)
mi_panel_scrollable.grid(row=0,column=0,sticky='nsew')
mi_panel_scrollable.grid_columnconfigure(0,minsize=200, weight=1)
mi_panel_scrollable.grid_columnconfigure(1,minsize=200, weight=1)
mi_panel_scrollable.grid_columnconfigure(2,minsize=200, weight=1)
mi_panel_scrollable.grid_columnconfigure(3,minsize=200, weight=1)
# ******botón de seleccionar todos/deseleccionar todos************************************
boton_marcar_todos=ctk.CTkButton(mi_panel_scrollable,text='Marcar-Desmarcar todo',font=('Quicksand',15,'bold'),corner_radius=8,text_color='black',
                                 fg_color=fondo_boton_seleccionar_categorias_colores_jugador,border_width=4,border_color=verde_andaluz,hover_color='white')
boton_marcar_todos.grid(row=0, column=0, sticky='we', pady=1,padx=5)
boton_marcar_todos.configure(command=marcar_botones_categorias)
# **************************************************************frame_players_modos_juego *********************************************************************************
label_sin_limite_segundos=ctk.CTkLabel(frame_players_modos_juego,text='\nLímite de tiempo\n',font=('Quicksand',25,'bold'),border_color='black',border_width=3,corner_radius=8,
                                       fg_color='white',text_color='black',height=70)
label_sin_limite_segundos.grid_configure(row=0,column=0,sticky='wens',padx=10,pady=10)
label_con_limite_errores=ctk.CTkLabel(frame_players_modos_juego,text='\nLímite de errores\n',font=('Quicksand',25,'bold'),border_color='black',border_width=3,corner_radius=8,
                                      fg_color='white',text_color='black',height=70)
label_con_limite_errores.grid_configure(row=0,column=1,sticky='wens',padx=10,pady=10)
boton_3_errores=ctk.CTkButton(frame_players_modos_juego,command=cambia_color_boton_3_errores,text='Límite=3 errores',font=('Quicksand',25,'bold'),fg_color=fondo_botones_limites,
                              border_color='black',border_width=4,corner_radius=8,text_color='black',height=50,width=250)
boton_3_errores.grid_configure(row=1,column=1,pady=10)
boton_5_errores=ctk.CTkButton(frame_players_modos_juego,command=cambia_color_boton_5_errores,text='Límite=5 errores',font=('Quicksand',25,'bold'),fg_color=fondo_botones_limites,
                              border_color='black',border_width=4,corner_radius=8,text_color='black',height=50,width=350)
boton_5_errores.grid_configure(row=2,column=1,pady=10)
boton_10_errores=ctk.CTkButton(frame_players_modos_juego,command=cambia_color_boton_10_errores,text='Límite=10 errores',font=('Quicksand',25,'bold'),fg_color=verde_andaluz,
                               border_color='black',border_width=4,corner_radius=8,text_color='black',height=50,width=450)
boton_10_errores.grid_configure(row=3,column=1,pady=10)
boton_inf_errores=ctk.CTkButton(frame_players_modos_juego,command=cambia_color_boton_inf_errores,text='Sin límite de errores',font=('Quicksand',25,'bold'),fg_color=fondo_botones_limites,
                                border_color='black',border_width=4,corner_radius=8,text_color='black',height=50,width=550)
boton_inf_errores.grid_configure(row=4,column=1,pady=10)
#************************************Creación lista de botones de límite de errores*******************************************
botones_del_limite_errores=[boton_3_errores,boton_5_errores,boton_10_errores,boton_inf_errores]#*****************************
#*****************************************************************************************************************************
boton_3_segundos=ctk.CTkButton(frame_players_modos_juego,command=cambia_color_boton_3_segundos,text='Límite=3 segundos',fg_color=fondo_botones_limites,font=('Quicksand',25,'bold'),
                               border_color='black',border_width=4,corner_radius=8,text_color='black',height=50,width=250)
boton_3_segundos.grid_configure(row=1,column=0,pady=10)
boton_5_segundos=ctk.CTkButton(frame_players_modos_juego,command=cambia_color_boton_5_segundos,text='Límite=5 segundos',fg_color=fondo_botones_limites,font=('Quicksand',25,'bold'),
                               border_color='black',border_width=4,corner_radius=8,text_color='black',height=50,width=350)
boton_5_segundos.grid_configure(row=2,column=0,pady=10)
boton_10_segundos=ctk.CTkButton(frame_players_modos_juego,command=cambia_color_boton_10_segundos,fg_color=verde_andaluz,text='Límite=10 segundos',font=('Quicksand',25,'bold'),
                                border_color='black',border_width=4,corner_radius=8,text_color='black',height=50,width=450)
boton_10_segundos.grid_configure(row=3,column=0,pady=10)
boton_inf_segundos=ctk.CTkButton(frame_players_modos_juego,command=cambia_color_boton_inf_segundos,text='Sin límite de tiempo',fg_color=fondo_botones_limites,font=('Quicksand',25,'bold'),
                                 border_color='black',border_width=4,corner_radius=8,text_color='black',height=50,width=550)
boton_inf_segundos.grid_configure(row=4,column=0,pady=10)
#************************************Creación lista de botones de límite de segundos*******************************************
botones_del_limite_segundos=[boton_3_segundos,boton_5_segundos,boton_10_segundos,boton_inf_segundos]#**************************
#******************************************************************************************************************************
frame_players_modos_juego.grid_columnconfigure(0,weight=1,minsize=550)
frame_players_modos_juego.grid_columnconfigure(1,weight=1,minsize=550)
# ***********widgets de  frame_botton_labels*****************************************************************************************
boton_start_game=ctk.CTkButton(frame_botton_labels,state='disabled',text='',corner_radius=8,fg_color='transparent',command=check_before_start)
label_warning=ctk.CTkLabel(frame_botton_labels,text='',corner_radius=8)
# ***********grid de widgets de frame_botton_labels************
frame_botton_labels.rowconfigure(0,weight=1)
frame_botton_labels.columnconfigure(0,weight=1)
boton_start_game.grid_configure(row=0,column=0,columnspan=3,sticky='we',padx=10,pady=10)
label_warning.grid_configure(row=1,column=0,columnspan=3,rowspan=3,sticky='we',padx=10,pady=10)
# ***************************************FRAME_JUEGO:widgets y grids ******************************************************
# ********************CREACIÓN FRAME DE TRANSICIÓN DE RUTINAS Y ENTRE PREGUNTAS********************************************
frame_info_1_jugador=ctk.CTkFrame(frame_juego,fg_color=fondo_frame_transicion)
# *************************************widget de transición frame_info_1_jugador ***************************************************************
label_ready_player_one=ctk.CTkLabel(frame_info_1_jugador,text='Categoría?',wraplength=350,text_color='black',fg_color='white',font=('Quicksand',25,'bold'),corner_radius=8)
button_ready_player_one=ctk.CTkButton(frame_info_1_jugador, text='¿Listo\nPlayer One?',height=100,text_color='black',fg_color=verde_andaluz,font=('Quicksand',25,'bold'),
                                      corner_radius=8,border_width=8,border_color=verde_andaluz,hover_color='white')
frame_info_1_jugador.place(relx=0.5,rely=0.5,anchor='center',relwidth=0.7,relheight=0.5)
label_ready_player_one.grid_configure(row=1,column=1,sticky='we',padx=20,pady=20)
button_ready_player_one.grid_configure(row=2,column=1,sticky='we',pady=20)
frame_info_1_jugador.rowconfigure(0,weight=3)
frame_info_1_jugador.rowconfigure(1,weight=0)
frame_info_1_jugador.rowconfigure(2,weight=0)
frame_info_1_jugador.rowconfigure(3,weight=1)
frame_info_1_jugador.columnconfigure(0,weight=3)
frame_info_1_jugador.columnconfigure(1,weight=1)
frame_info_1_jugador.columnconfigure(2,weight=3)
# ******************crear frame para stats de jugador, y la zona de preguntas y respuestas*******************************
frame_stats_players=ctk.CTkFrame(frame_juego,height=150)
frame_quiz=ctk.CTkFrame(frame_juego)
# *********hago que el grid de frame_juego se expanda en columnas y filas********
# en la siguiente línea se queda el weight=0 porque es el valor por defecto y no tiende a agrandar el frame. Este se queda con el valor que le hemos dado en height=150 al crearlo. Lo dejo así porque la
# apariencia es más predecible con los valores que se escriben. La proporción que se usa con weight es menos directa que escribir el valor de su altura o ancho.
frame_juego.rowconfigure(0,weight=0)  #esta línea en teoría no es necesarria
frame_juego.columnconfigure(0,weight=1)
frame_juego.rowconfigure(1,weight=7)
# ********************************Colocar cada frame en su sitio en el grid*************************************************
frame_stats_players.grid(row=0,column=0,sticky='nswe')
frame_quiz.grid(row=1,column=0,sticky='nswe')
#la línea de debajo evita que el frame_stats_players aumente de tamaño al meterle widgets en su interior. Esto se hace ya que al crearlo le dimos un tamaño definido usando height=150
frame_stats_players.grid_propagate(False)
# ************************doy color a los dos subframes para diferenciarlos bien ahora (y cuando acabe les daré el color definitvo)
frame_stats_players.configure(fg_color=fondo_frame_stats_players)
frame_quiz.configure(fg_color=fondo_frame_quiz)
# *******************************Vamos a crear los widgets del frame_stats_quiz*************************************************
boton_volver_a_bienvendida=ctk.CTkButton(frame_stats_players,text='Volver',width=100,font=('Quicksand',15,'bold'),corner_radius=8,text_color='white',fg_color='gray',
                                         hover_color='black',command=go_to_bienvenida_from_game_questions)
label_marcador_P1=ctk.CTkLabel(frame_stats_players,text='Jugador',fg_color=fondo_etiquetas_marcadors,font=('Quicksand',25,'bold'),width=200,border_width=4,
                               border_color=fondo_etiquetas_marcadors)
label_marcador_P2_numero_preguntas=ctk.CTkLabel(frame_stats_players,text='Preguntas',fg_color=fondo_etiquetas_marcadors,font=('Quicksand',25,'bold'),
                                                border_width=4,border_color=fondo_etiquetas_marcadors)
label_marcador_P3_Aciertos=ctk.CTkLabel(frame_stats_players,text='Aciertos',fg_color=fondo_etiquetas_marcadors,font=('Quicksand',25,'bold'),
                                        border_width=4,border_color=verde_andaluz)
label_marcador_P3_Fallos=ctk.CTkLabel(frame_stats_players,text='Fallos',fg_color=fondo_etiquetas_marcadors,font=('Quicksand',25,'bold'),border_width=4,border_color='red')
label_marcador_P4_Categorias=ctk.CTkLabel(frame_stats_players,text='Categoría Actual',fg_color=fondo_etiquetas_marcadors,font=('Quicksand',25,'bold'),
                                          border_width=4,border_color=fondo_etiquetas_marcadors)
logo_PIl_countdown=Image.open(os.path.join(carpeta_imagenes,'infinito.png'))
logo_ctk_countdown=ctk.CTkImage(light_image=logo_PIl_countdown,size=(150,100))
label_countdown=ctk.CTkLabel(frame_stats_players,text='Cuenta\nAtrás',fg_color='black',text_color='white',font=('Quicksand',50,'bold'))
# *******************************Ahora vamos a colocar los widgets de frame_stats_quiz en su grid*******************************
boton_volver_a_bienvendida.grid_configure(row=0,column=0,padx=25)
label_marcador_P1.grid_configure(row=0,column=1,sticky='nsew')
label_marcador_P2_numero_preguntas.grid_configure(row=1,column=0,sticky='nsew')
label_marcador_P3_Aciertos.grid_configure(row=0,column=2,sticky='nsew')
label_marcador_P3_Fallos.grid_configure(row=0,column=3,sticky='nsew')
label_marcador_P4_Categorias.grid_configure(row=1,column=1,columnspan=3,sticky='nsew')
label_countdown.grid_configure(row=0,column=4,rowspan=2,sticky='nswe')#,padx=10,pady=10)
# *********************************************doy los pesos de las filas y columnas del frame_stats_quiz**************************************************************************
frame_stats_players.rowconfigure(0,weight=1,minsize=50)
frame_stats_players.rowconfigure(1,weight=1)
frame_stats_players.columnconfigure(0,weight=1)
frame_stats_players.columnconfigure(1,weight=1)
frame_stats_players.columnconfigure(2,weight=1)
frame_stats_players.columnconfigure(3,weight=1)
# doy los pesos de las filas y columnas del frame_quiz**************************************************************************
frame_quiz.rowconfigure(0,weight=10)
frame_quiz.rowconfigure(1,weight=3)
frame_quiz.rowconfigure(2,weight=3)
frame_quiz.columnconfigure(0,weight=1)
frame_quiz.columnconfigure(1,weight=1)
# ******************creo los widgets de frame_quiz*******************************************************************************
label_question=ctk.CTkLabel(frame_quiz,text='Question',font=('Quicksand',40,'bold'),wraplength=700,fg_color=fondo_label_question,border_color='white',border_width=12)
boton_left_up=ctk.CTkButton(frame_quiz,text='Respuesta',text_color='black',fg_color='white',font=('Quicksand',25,'bold'),corner_radius=8,border_width=8,
                            border_color=verde_andaluz,hover_color=verde_andaluz,state='disabled')
boton_left_down=ctk.CTkButton(frame_quiz,text='Respuesta',text_color='black',fg_color='white',font=('Quicksand',25,'bold'),corner_radius=8,border_width=8,
                              border_color=verde_andaluz,hover_color=verde_andaluz,state='disabled')
boton_right_up=ctk.CTkButton(frame_quiz,text='Respuesta',text_color='black',fg_color='white',font=('Quicksand',25,'bold'),corner_radius=8,border_width=8,
                             border_color=verde_andaluz,hover_color=verde_andaluz,state='disabled')
boton_right_down=ctk.CTkButton(frame_quiz,text='Respuesta',text_color='black',fg_color='white',font=('Quicksand',25,'bold'),corner_radius=8,border_width=8,
                               border_color=verde_andaluz,hover_color=verde_andaluz,state='disabled')
# ******************coloco los widgets de frame_quiz en su grid*******************************************************************
label_question.grid_configure(row=0,column=0,columnspan=3,sticky='nswe',padx=10,pady=10)
boton_left_up.grid_configure(row=1,column=0,sticky='nswe',padx=10,pady=10)
boton_left_down.grid_configure(row=2,column=0,sticky='nswe',padx=10,pady=10)
# label_countdown.grid_configure(row=1,column=1,columnspan=1,rowspan=2,sticky='nswe',padx=10,pady=10)
boton_right_up.grid_configure(row=1,column=1,sticky='nswe',padx=10,pady=10)
boton_right_down.grid_configure(row=2,column=1,sticky='nswe',padx=10,pady=10)
frame_welcome.tkraise()#SOLO ASÍ MIENTRAS TRABAJO CON FRAME_JUEGO. FRAME_INICIO ES EL PRIMER FRAME QUE SE VE AL ARRANCAR EL JUEGO
# frame_juego.tkraise()
root.mainloop()





















